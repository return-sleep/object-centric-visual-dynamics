# Balls pretrained checkpoints

Matching perception and dynamics checkpoints for the short-horizon Balls result in Learning Visual Dynamics via Unsupervised Object-centric Prediction.

Extract this archive at the root of https://github.com/return-sleep/object-centric-visual-dynamics. Follow docs/DATASETS.md to register the CoPhy data, then run:

```sh
python tools/run.py --dataset ballsCF --mode eval
```

The full supplied test split contains 188 videos, with 3 conditioning frames and 25 predicted frames at 112 x 112. Public-entry evaluation: L-PSNR 34.115024 dB (34.12 rounded). An independent evaluation of the same weights yielded 34.115361 dB. The original revision-stage evaluation was 34.116105 dB; the manuscript retains its complete metric row. These are separate evaluation records, not interchangeable individual metrics. Small numerical differences can occur across environments; see docs/validation.json for the evaluated environment and split hash.

Verify files from this extracted directory with `shasum -a 256 -c SHA256SUMS`. Only the two model weight files are included; no training data is distributed. See the source repository for code and third-party notices.
