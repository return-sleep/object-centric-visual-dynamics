# Blocktower pretrained checkpoints

Matching perception and dynamics weights for object-centric-visual-dynamics. Extract at the repository root, register the dataset following docs/DATASETS.md, and run:

```sh
shasum -a 256 -c BLOCKTOWER_SHA256SUMS
python tools/run.py --dataset blocktowerCF --mode eval
```

Evaluation uses the complete supplied test split, with one conditioning frame and 25 predicted frames. See docs/RESULTS.md and docs/validation.json for reference results and the evaluated environment. No training data is included.
